const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Mock emotion analysis - basic heuristics based on metadata
app.post('/api/analyze', (req, res) => {
  const { text, metadata } = req.body || {};
  // metadata: { typingSpeed, pauses, edits, backspaces, length }
  const score = (() => {
    let s = 0;
    if(metadata.typingSpeed < 200) s += 1; // fast typers slightly positive
    if(metadata.pauses > 2) s -= 1; // many pauses -> hesitation
    if(metadata.edits > 3) s -= 1; 
    if(metadata.backspaces > 5) s -= 1;
    if((text||'').includes('?')) s += 0; // neutral
    return s;
  })();
  let emotion = 'neutral';
  if(score >= 1) emotion = 'engaged';
  if(score <= -2) emotion = 'hesitant';
  if(score <= -3) emotion = 'anxious';

  // demo explanation & suggestions
  const suggestions = {
    engaged: ['Mirror tone: show warmth', 'Ask an open question to deepen bond'],
    hesitant: ['Use validating language', 'Offer gentle prompt to continue'],
    anxious: ['Slow down, acknowledge feelings', 'Use empathetic short replies'],
    neutral: ['Share a small personal anecdote', 'Ask about interests']
  };

  res.json({ emotion, suggestions: suggestions[emotion], score, received: { text, metadata } });
});

// Mock match/story endpoint - returns staged reveal content
app.get('/api/match', (req, res) => {
  const story = [
    {stage:1, title:'Little wins', hint:'Loves sunrise walks' },
    {stage:2, title:'Hidden hobby', hint:'Makes miniature models' },
    {stage:3, title:'Shared dream', hint:'Wants to travel to Faroe Islands' }
  ];
  res.json({ story });
});

app.listen(port, () => {
  console.log(`YmiRa prototype server listening on http://localhost:${port}`);
});
