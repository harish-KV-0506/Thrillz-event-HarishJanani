// Frontend logic: capture typing metadata, send to backend, show mock emotion analysis.
// Also simple story reveal & micro-interactions.

const composer = document.getElementById('composer');
const sendBtn = document.getElementById('send-btn');
const chatBox = document.getElementById('chat-box');
const analysis = document.getElementById('analysis');
const revealBtn = document.getElementById('reveal-btn');
const petals = document.getElementById('petals');
const storyList = document.getElementById('story-list');
const promptBtn = document.getElementById('prompt-btn');
const gameDiv = document.getElementById('game');

// Typing metadata capture
let metadata = { typingStart: null, keyCount:0, backspaces:0, edits:0, pauses:0 };
let lastKeyTime = null;
let pauseTimer = null;

composer.addEventListener('keydown', (e)=>{
  const now = Date.now();
  if(!metadata.typingStart) metadata.typingStart = now;
  metadata.keyCount += 1;
  if(e.key === 'Backspace') metadata.backspaces += 1;
  lastKeyTime = now;

  if(pauseTimer) clearTimeout(pauseTimer);
  pauseTimer = setTimeout(()=>{
    metadata.pauses += 1;
    // small visual micro-interaction
    petals.classList.remove('reveal');
  }, 900); // pause threshold
});

composer.addEventListener('input', (e)=>{
  metadata.edits += 1;
});

function computeMetadata(){
  const now = Date.now();
  const duration = metadata.typingStart ? (now - metadata.typingStart) : 1;
  const typingSpeed = metadata.keyCount > 0 ? Math.round(duration / metadata.keyCount) : 400;
  return {
    typingSpeed, pauses: metadata.pauses, edits: metadata.edits, backspaces: metadata.backspaces, length: composer.value.length
  };
}

sendBtn.addEventListener('click', async ()=>{
  const text = composer.value.trim();
  if(!text) return;
  // show in chat
  const p = document.createElement('div'); p.textContent = 'You: ' + text; p.className='small-note'; chatBox.appendChild(p);
  // compute metadata and send to /api/analyze
  const meta = computeMetadata();
  // reset capture
  metadata = { typingStart: null, keyCount:0, backspaces:0, edits:0, pauses:0 };
  composer.value='';
  analysis.textContent = 'Analyzing...';
  try{
    const res = await fetch('/api/analyze', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ text, metadata: meta })});
    const data = await res.json();
    const r = document.createElement('div');
    r.innerHTML = '<strong>AI:</strong> Detected emotion: <em>'+data.emotion+'</em><br/>Suggestions: '+data.suggestions.join(' • ');
    chatBox.appendChild(r);
    analysis.textContent = 'Score: '+data.score;
    // micro-interaction: show petals or butterflies depending on emotion
    if(data.emotion === 'engaged') {
      petals.classList.add('reveal');
      confettiBlossom();
    } else if(data.emotion === 'hesitant' || data.emotion === 'anxious') {
      petals.classList.remove('reveal');
    }
  }catch(err){
    analysis.textContent = 'Error analyzing';
    console.error(err);
  }
  chatBox.scrollTop = chatBox.scrollHeight;
});

// Story reveal flow
let story = [];
let stage = 0;
async function loadStory(){
  const res = await fetch('/api/match'); const j = await res.json();
  story = j.story || [];
  renderStory();
}
function renderStory(){
  storyList.innerHTML='';
  story.slice(0, stage).forEach(s=>{
    const li = document.createElement('li');
    li.textContent = s.title + ' — ' + s.hint;
    storyList.appendChild(li);
  });
}
revealBtn.addEventListener('click', ()=>{
  if(stage >= story.length) return;
  stage += 1;
  // reveal micro-animation
  petals.classList.add('reveal');
  setTimeout(()=>{ petals.classList.remove('reveal'); }, 1200);
  renderStory();
});

// simple mini-game prompt
const prompts = [
  'Two truths and a lie: Share 2 unusual facts + one false one',
  'Describe your first childhood memory in one sentence',
  'If you could live anywhere, where and why?'
];
promptBtn.addEventListener('click', ()=>{
  const p = prompts[Math.floor(Math.random()*prompts.length)];
  gameDiv.textContent = p;
});

function confettiBlossom(){
  // small DOM blossom (no external libs)
  const el = document.createElement('div'); el.textContent='💫'; el.className='butterfly'; document.body.appendChild(el);
  setTimeout(()=>{ el.style.opacity = 0.5; }, 80);
  setTimeout(()=>{ el.remove(); }, 1800);
}

loadStory();
