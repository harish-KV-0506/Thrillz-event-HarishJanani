# YmiRa — Build to Bond Prototype (Demo Submission)

Team: YmiRa (Janani J, Harish KV)

This is a lightweight working prototype demonstrating core flows:
- Typing metadata capture (typing speed, pauses, edits)
- Mock Emotion Analysis API
- Slow-match story-driven discovery
- Micro-interactions (petals reveal animation, butterflies)

How to run (locally):
1. Ensure Node.js (v14+) is installed.
2. Open terminal in this folder.
3. Run `npm install`
4. Run `node server.js`
5. Open http://localhost:3000 in your browser.

Files:
- server.js         : Node/Express backend (mock AI endpoints)
- package.json      : Node metadata
- public/index.html : Frontend single-page app
- public/app.js     : Frontend logic (typing metadata capture, UI flows)
- public/styles.css : CSS & animations

This prototype is intentionally small; replace mock AI with your models as needed.
